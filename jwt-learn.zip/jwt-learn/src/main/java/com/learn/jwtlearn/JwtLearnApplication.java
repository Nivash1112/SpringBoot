package com.learn.jwtlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtLearnApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtLearnApplication.class, args);
	}

}
