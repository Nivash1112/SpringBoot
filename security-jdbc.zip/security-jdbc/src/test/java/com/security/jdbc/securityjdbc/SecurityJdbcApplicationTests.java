package com.security.jdbc.securityjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
